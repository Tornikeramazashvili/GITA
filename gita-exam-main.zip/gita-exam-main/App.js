import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import StackNav from "./src/navigation/StackNav";

import { useFonts } from "expo-font";

function App() {
  const [loaded] = useFonts({
    Montserrat: require("./src/assets/fonts/Montserrat-Regular.ttf"),
  });

  if (!loaded) {
    return null;
  }

  return (
    <NavigationContainer>
      <StackNav />
    </NavigationContainer>
  );
}
export default App;
