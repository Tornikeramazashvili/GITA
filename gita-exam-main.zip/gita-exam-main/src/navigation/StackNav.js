import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

// Imported screens and bottom navigation
import SplashScreen from "../screens/SplashScreen";
import LoginScreen from "../screens/LoginScreen";
import BookVilla from "../components/BookVilla"
import BookingsScreen from "../screens/BookingsScreen";
import BookingConfirm from '../components/BookingConfirm'
import LocationScreen from "../screens/LocationScreen";
import BottomNav from "../navigation/BottomNav";

const Stack = createStackNavigator();

function StackNav() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Bottom" component={BottomNav} />
      <Stack.Screen name="BookVilla" component={BookVilla} />
      <Stack.Screen name="BookingConfirm" component={BookingConfirm} />
      <Stack.Screen name="Booking" component={BookingsScreen} />
      <Stack.Screen name="Location" component={LocationScreen} />
    </Stack.Navigator>
  );
}

export default StackNav;
