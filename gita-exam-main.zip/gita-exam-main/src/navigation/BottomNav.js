import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

// imported screens
import HomeScreen from "../screens/HomeScreen";
import LocationScreen from "../screens/LocationScreen";
import BookingScreen from "../screens/BookingsScreen";
import ProfileScreen from "../screens/ProfileScreen";
import MoreScreen from "../screens/MoreScreen";

// Imported Icons for bottom navigation
import Home from "react-native-vector-icons/Feather";
import Location from "react-native-vector-icons/Ionicons";
import Booking from "react-native-vector-icons/AntDesign";
import Profile from "react-native-vector-icons/Ionicons";
import More from "react-native-vector-icons/Octicons";

const Tab = createBottomTabNavigator();

function BottomNav() {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: "#B2002D",
        tabBarStyle: {
          paddingBottom: 4,
          paddingTop: 4,
          height: 54,
          borderTopColor: "transparent",
          shadowColor: "transparent",
        },
        tabBarLabelStyle: {
          fontSize: 12,
        },
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarLabel: "Home",
          tabBarIcon: ({ color }) => (
            <Home name="home" color={color} size={21} />
          ),
        }}
      />
      <Tab.Screen
        name="Location"
        component={LocationScreen}
        options={{
          tabBarLabel: "Location",
          tabBarIcon: ({ color }) => (
            <Location name="search-outline" color={color} size={21} />
          ),
        }}
      />
      <Tab.Screen
        name="Bookings"
        component={BookingScreen}
        options={{
          tabBarLabel: "Bookings",
          tabBarIcon: ({ color }) => (
            <Booking name="hearto" color={color} size={21} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarLabel: "Profile",
          tabBarIcon: ({ color }) => (
            <Profile name="person-outline" color={color} size={21} />
          ),
        }}
      />
      <Tab.Screen
        name="More"
        component={MoreScreen}
        options={{
          tabBarLabel: "More",
          tabBarIcon: ({ color }) => (
            <More name="three-bars" color={color} size={21} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default BottomNav;
