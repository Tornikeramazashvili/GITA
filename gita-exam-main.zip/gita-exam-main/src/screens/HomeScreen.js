import React from "react";
import { ScrollView, StyleSheet, View } from "react-native";

// Imorted data and component
import ApartamentsData from "../services/ApartamentsData";
import ApartamentsInfo from "../components/ApartamentsInfo";

export default function HomeScreen() {
  return (
    <View style={styles.ScreenBackgroundColor}>
      <ScrollView style={styles.container}>
        {ApartamentsData.map((apartament, index) => {
          return (
            <ApartamentsInfo
              key={index}
              id={apartament.id}
              image={apartament.image}
              name={apartament.name}
              price={apartament.price}
              address={apartament.address}
              bedRoom={apartament.bedRoom}
              totalArea={apartament.totalArea}
            />
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  ScreenBackgroundColor: {
    backgroundColor: "#ffffff"
  },
  container: {
    contentContainerStyle: {
      flexGrow: 1,
    },
    marginTop: 50,
    marginHorizontal: 5,
  },
});
