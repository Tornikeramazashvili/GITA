import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image } from "react-native";

// Imported Icons
import ArrowLeft from "react-native-vector-icons/Octicons"
import Bookings from "react-native-vector-icons/Ionicons"
import ArrowRight from 'react-native-vector-icons/AntDesign'
import Visits from "react-native-vector-icons/Fontisto"
import Payment from "react-native-vector-icons/MaterialIcons"
import Feedback from "react-native-vector-icons/MaterialIcons"

export default function ProfileScreen({ navigation: { navigate } }) {
  return <>
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigate('Bookings')}>
          <ArrowLeft name="chevron-left" size={33} color="#B2002D" />
        </TouchableOpacity>
      </View>
      <View style={styles.profile}>
        <View>
          <Image source={require('../assets/images/profile.jpg')} resizeMode="cover" style={styles.image} />
        </View>
        <View style={styles.profileInformation}>
          <Text style={styles.name}>Jane Doe</Text>
          <Text style={styles.email}>janedoe123@email.com</Text>
          <TouchableOpacity activeOpacity={0.7} style={styles.button}>
            <Text style={styles.buttonText}>EDIT PROFILE</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.content}>
        <TouchableOpacity onPress={() => navigate('Bookings')} style={styles.contentTextBox} activeOpacity={0.7} >
          <View style={styles.contentTextAndIconBox}>
            <View>
              <Bookings name="list" color={"#7b808e"} size={22} />
            </View>
            <Text style={styles.contentText}>All My Booking</Text>
          </View>
          <View>
            <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
          <View style={styles.contentTextAndIconBox}>
            <View>
              <Visits name="hot-air-balloon" style={styles.VisitsIcon} color={"#7b808e"} size={22} />
            </View>
            <Text style={styles.contentText}>Pending Visits</Text>
          </View>
          <View>
            <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
          <View style={styles.contentTextAndIconBox}>
            <View>
              <Payment name="payment" color={"#7b808e"} size={22} />
            </View>
            <Text style={styles.contentText}>Pending Payments</Text>
          </View>
          <View>
            <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
          <View style={styles.contentTextAndIconBox}>
            <View>
              <Feedback name="feedback" color={"#7b808e"} size={22} />
            </View>
            <Text style={styles.contentText}>Feedback</Text>
          </View>
          <View>
            <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  </>
}

const styles = StyleSheet.create({
  container: {
    marginTop: 53,
    marginHorizontal: 5,
  },
  header: {
    marginHorizontal: 10,
  },
  image: {
    width: 110,
    height: 110,
    borderRadius: 100
  },
  profile: {
    flexDirection: "row",
    alignItems: 'center',
    justifyContent: "space-around",
  },
  name: {
    fontSize: 30,
    color: "#7b808e",
    fontWeight: "bold",
    marginBottom: 20
  },
  email: {
    fontSize: 15,
    color: "#7b808e",
    marginBottom: 20
  },
  button: {
    borderColor: "#b6babc",
    borderWidth: 1,
    width: 130,
    paddingVertical: 6,
    alignItems: 'center',
    borderRadius: 40
  },
  buttonText: {
    color: "#7b808e",
    fontWeight: "bold"
  },
  content: {
    paddingHorizontal: 16,
    paddingVertical: 5,
    marginTop: 40,
    marginHorizontal: 10,
    backgroundColor: "#ffffff",
    borderRadius: 10,

  },
  contentTextBox: {
    alignItems: 'center',
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8

  },
  contentTextAndIconBox: {
    flexDirection: "row",
    alignItems: 'center'
  },
  VisitsIcon: {
    marginLeft: 3
  },
  contentText: {
    color: "#7b808e",
    fontSize: 17,
    marginLeft: 24,
  }
})

