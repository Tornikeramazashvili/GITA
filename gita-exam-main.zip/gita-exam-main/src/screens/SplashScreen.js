import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
} from "react-native";

// Imported Icon
import Arrow from "react-native-vector-icons/MaterialCommunityIcons";

export default function SplashScreen({ navigation }) {
  return (
    <>
      <ScrollView>
        <View style={styles.container}>
          <View style={styles.titleContainer}>
            <Text style={styles.title}>LongStay Villa</Text>
          </View>
          <View style={styles.imageContainer}>
            <Image source={require("../assets/images/Splash.jpg")} resizeMode="cover" />
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.button}
              onPress={() => navigation.navigate("Login")}
            >
              <Text style={styles.buttonText}>GET STARTED</Text>
              <Arrow
                style={styles.arrow}
                color="#ffffff"
                name="arrow-right"
                size={20}
              />
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 50,
  },
  title: {
    fontSize: 58,
    color: "#B2002D",
    fontFamily: "Montserrat",
    fontWeight: "bold",
  },
  imageContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 6,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  button: {
    marginTop: 20,
    backgroundColor: "#B2002D",
    paddingHorizontal: 10,
    paddingVertical: 16,
    borderTopLeftRadius: 30,
    borderBottomLeftRadius: 30,
    flexDirection: "row",
    alignItems: "center",
  },
  buttonText: {
    color: "#ffffff",
    fontFamily: "Montserrat",
    justifyContent: "center",
    marginRight: 10,
  },
});
