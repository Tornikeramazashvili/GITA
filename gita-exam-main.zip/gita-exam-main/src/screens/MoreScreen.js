import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

// Imported Icons
import Close from "react-native-vector-icons/AntDesign"
import ArrowRight from 'react-native-vector-icons/AntDesign'
import Bookings from "react-native-vector-icons/Entypo"
import Payment from "react-native-vector-icons/MaterialCommunityIcons"
import Currency from "react-native-vector-icons/Ionicons"
import Language from "react-native-vector-icons/Ionicons"

export default function MoreScreen({ navigation: { navigate } }) {
  return (
    <>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigate('Profile')}>
            <Close name="close" size={33} color="#B2002D" />
          </TouchableOpacity>
        </View>
        <View style={styles.content}>
          <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
            <View style={styles.contentTextAndIconBox}>
              <View>
                <Bookings name="location" color={"#7b808e"} size={22} />
              </View>
              <Text style={styles.contentText}>Booking Address</Text>
            </View>
            <View>
              <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
            <View style={styles.contentTextAndIconBox}>
              <View>
                <Payment name="account-cash-outline" style={styles.VisitsIcon} color={"#7b808e"} size={22} />
              </View>
              <Text style={styles.contentText}>Payment Method</Text>
            </View>
            <View>
              <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
            <View style={styles.contentTextAndIconBox}>
              <View>
                <Currency name="wallet-outline" color={"#7b808e"} size={22} />
              </View>
              <Text style={styles.contentText}>Currency</Text>
              <Text style={styles.contentTextUSD}>USD</Text>
            </View>
            <View>
              <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity style={styles.contentTextBox} activeOpacity={0.7} >
            <View style={styles.contentTextAndIconBox}>
              <View>
                <Language name="language" color={"#7b808e"} size={22} />
              </View>
              <Text style={styles.contentText}>Language</Text>
              <Text style={styles.contentTextENG}>English</Text>
            </View>
            <View>
              <ArrowRight name="rightcircle" color="#B0B0B0" size={18} />
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.logOutBox}>
          <TouchableOpacity activeOpacity={0.5} style={styles.logOut}
            onPress={() => navigate("Login")}>
            <Text style={styles.logOutText}>Log out</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    contentContainerStyle: {
      flexGrow: 1,
    },
    marginTop: 50,
    marginHorizontal: 5,
  },
  header: {
    marginHorizontal: 10,
    flexDirection: "row",
    justifyContent: "flex-end"
  },
  image: {
    width: 110,
    height: 110,
    borderRadius: 100
  },
  profile: {
    flexDirection: "row",
    alignItems: 'center',
    justifyContent: "space-around",
  },
  name: {
    fontSize: 30,
    color: "#7b808e",
    fontWeight: "bold",
    marginBottom: 20
  },
  email: {
    fontSize: 15,
    color: "#7b808e",
    marginBottom: 20
  },
  button: {
    borderColor: "#b6babc",
    borderWidth: 1,
    width: 130,
    paddingVertical: 6,
    alignItems: 'center',
    borderRadius: 40
  },
  buttonText: {
    color: "#7b808e",
    fontWeight: "bold"
  },
  content: {
    paddingHorizontal: 16,
    paddingVertical: 5,
    marginTop: 20,
    marginHorizontal: 10,
    backgroundColor: "#ffffff",
    borderRadius: 10,

  },
  contentTextBox: {
    alignItems: 'center',
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 8

  },
  contentTextAndIconBox: {
    flexDirection: "row",
    alignItems: 'center'
  },
  VisitsIcon: {
    marginLeft: 3
  },
  contentText: {
    color: "#7b808e",
    fontSize: 17,
    marginLeft: 24,
  },
  contentTextUSD: {
    color: "#7b808e",
    fontSize: 17,
    marginLeft: 100,
  },
  contentTextENG: {
    color: "#7b808e",
    fontSize: 17,
    marginLeft: 70,
  },
  logOutBox: {
    alignItems: 'center'
  },
  logOut: {
    justifyContent: "center",
    width: "30%",
    marginTop: 50
  },
  logOutText: {
    textAlign: "center",
    textTransform: "uppercase",
    color: "#B2002D"
  }
})

