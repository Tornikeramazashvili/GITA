import React, { useState } from "react";
import { View, StyleSheet, TextInput, TouchableOpacity } from "react-native";

// Imported icons
import ArrowLeft from "react-native-vector-icons/Octicons"
import Filter from "react-native-vector-icons/AntDesign"
import Search from 'react-native-vector-icons/Feather'

// imported data and component
import SearchFilter from "../components/SearchFilter";
import Apartaments from "../services/ApartamentsData";

export default function LocationScreen({ navigation: { navigate } }) {
  // Hook for input onchange
  const [input, setInput] = useState("")

  return (
    <View style={styles.ScreenBackgroundColor}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigate("Home")} style={styles.backButton}>
            <ArrowLeft name="chevron-left" size={33} color="#B2002D" />
          </TouchableOpacity>
          <View style={styles.searchBar}>
            <Search name="search" size={15} color="gray" />
            <TextInput
              value={input}
              onChangeText={(text) => setInput(text)}
              onFocus={() => setInput('')}
              placeholder="Aspen" style={styles.input} />
          </View>
          <Filter name="filter" size={29} color="gray" />
        </View>
        <SearchFilter data={Apartaments} input={input} setInput={setInput} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  ScreenBackgroundColor: {
    backgroundColor: "#ffffff"
  },
  container: {
    contentContainerStyle: {
      flexGrow: 1,
    },
    marginTop: 50,
    marginHorizontal: 5,
  },
  header: {
    marginHorizontal: 10,
    alignItems: 'center',
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10
  },
  backButton: {
    marginRight: 6
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 30,
    width: "84%",
    backgroundColor: "#f0f1f3",
    paddingVertical: 6,
    paddingHorizontal: 14,

  },
  input: {
    marginLeft: 10,
    fontSize: 14,
    paddingRight: 200,
  }
})

