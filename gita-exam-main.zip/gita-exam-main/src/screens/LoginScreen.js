import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
} from "react-native";

// Imported Icon
import Eye from "react-native-vector-icons/Feather";

export default function LoginScreen({ navigation }) {
  // Hooks for email and password validation
  const [email, setEmail] = useState("admin");
  const [password, setPassword] = useState("admin");

  // Hook for hiding and showing the password
  const [hidePass, setHidePass] = useState(true);

  // Event for preventing submit
  const handleSubmit = (event) => {
    event.preventDefault();
  };

  // Loop for log in only for admin
  const onLoginButton = () => {
    if (email === "admin" && password === "admin") {
      navigation.navigate("Bottom");
    } else {
      Alert.alert("Username/Password should be admin/admin.");
    }
  };

  return (
    <>
      <View style={styles.container}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputHeaderTitle}>Login Account</Text>
          <Text style={styles.inputTitle}>Email</Text>
          <TextInput
            onSubmitEditing={handleSubmit}
            style={styles.inputs}
            placeholder="Email"
            keyboardType="email-address"
            underlineColorAndroid="transparent"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
          <View style={styles.inputContainer}>
            <View>
              <Text style={styles.inputTitle}>Password</Text>
              <TextInput
                onSubmitEditing={handleSubmit}
                style={styles.inputs}
                placeholder="Password"
                secureTextEntry={hidePass ? true : false}
                underlineColorAndroid="transparent"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
              <Eye
                style={styles.passwordToggle}
                name={hidePass ? "eye" : "eye-off"}
                size={20}
                onPress={() => setHidePass(!hidePass)}
              />
            </View>
          </View>
          <TouchableOpacity
            activeOpacity={0.7}
            style={styles.loginButton}
            onPress={() => onLoginButton()}
          >
            <Text style={styles.loginButtonText}>Login</Text>
          </TouchableOpacity>
          <TouchableOpacity activeOpacity={0.7} style={styles.forgotButton}>
            <Text style={styles.forgotPasswordText}>Forgot password</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffffff",
  },
  inputs: {
    borderColor: "#C0C0C0",
    borderWidth: 1,
    borderRadius: 30,
    width: 320,
    paddingHorizontal: 20,
    paddingVertical: 12,
    fontFamily: "Montserrat",
  },
  inputContainer: {
    marginVertical: 20,
    position: "relative",
  },
  inputHeaderTitle: {
    fontFamily: "Montserrat",
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 40,
  },
  inputTitle: {
    marginBottom: 8,
    color: "black",
    fontFamily: "Montserrat",
  },
  passwordToggle: {
    position: "absolute",
    left: 280,
    top: 46,
  },
  loginButton: {
    borderRadius: 30,
    width: 320,
    paddingHorizontal: 20,
    paddingVertical: 14,
    backgroundColor: "#B2002D",
    marginTop: 12,
  },
  loginButtonText: {
    textAlign: "center",
    color: "#ffffff",
    textTransform: "uppercase",
    fontWeight: "bold",
    letterSpacing: 1,
    fontFamily: "Montserrat",
  },
  forgotPasswordText: {
    textAlign: "center",
    color: "#B2002D",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    fontWeight: "bold",
    fontFamily: "Montserrat",
  },
  forgotButton: {
    marginTop: 24,
  },
});
