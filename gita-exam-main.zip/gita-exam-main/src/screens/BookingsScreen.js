import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Image } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Imported Icon
import ArrowLeft from "react-native-vector-icons/Octicons"
import ArrowRight from "react-native-vector-icons/Ionicons"

export default function BookingsScreen({ navigation }) {

  // Hooks for respresenting AsyncStorage results
  const [results, setResults] = useState([])

  // Adding item with AsyncStorage
  const getData = async () => {
    try {
      const data = await AsyncStorage.getItem('booking')
      setResults(JSON.parse(data))
    } catch (error) {
      console.log(error)
    }
  }

  // Using useEffect to load the information once 
  useEffect(() => {
    getData()
  }, [results])
  // and update each time something updates in results

  // Removing item with AsyncStorage
  const removeData = async () => {
    try {
      await AsyncStorage.removeItem('booking')
      console.log(removeData)
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <>
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.headerTitleBox}>
            <TouchableOpacity activeOpacity={0.6} onPress={() => navigation.navigate('Location')} >
              <ArrowLeft name="chevron-left" size={33} color="#B2002D" />
            </TouchableOpacity>
            <View>
              <Text style={styles.headerTitle}>Bookings  History</Text>
            </View>
          </View>
          <TouchableOpacity onPress={removeData} activeOpacity={0.6}>
            <Text style={styles.removeAllBookings}>Remove all bookings</Text>
          </TouchableOpacity>
        </View>
        <ScrollView contentContainerStyle={styles.contentContainerStyle}>
          {results?.map((result, index) =>
            <View style={styles.contentBox} key={index}>
              <Image source={result.image} style={styles.image} />
              <View style={styles.contentInformationBox}>
                <Text style={styles.contentText}>{result.name}</Text>
                <Text style={styles.contentText}>Price: {result.price} Per Day  Total : $24000</Text>
                <Text style={styles.contentText}>Badroom: {result.bedRoom}</Text>
                <Text style={styles.contentText}>Total area: {result.totalArea}</Text>
                <Text style={styles.contentText}>Check In Date : 12 th April 2021</Text>
                <Text style={styles.contentText}>Check Out Date : 18 th April 2021</Text>
              </View>
              <View style={styles.buttonBox}>
                <TouchableOpacity onPress={() => navigation.navigate('Home')} activeOpacity={0.7} style={styles.bookButton}>
                  <Text style={styles.bookButtonText}>Book More</Text>
                  <ArrowRight name='ios-arrow-forward-circle-sharp' size={30} color="#ffffff"
                    style={styles.arrowRight} />
                </TouchableOpacity>
              </View>
            </View>)}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  image: {
    width: "100%",
    height: 224,
    resizeMode: "contain"
  },
  container: {
    marginTop: 53,
    marginHorizontal: 5,
  },
  contentContainerStyle: {
    flexGrow: 1,
    paddingBottom: 40
  },
  header: {
    marginHorizontal: 10,
    alignItems: 'center',
    flexDirection: "row",
    marginBottom: 10,
    justifyContent: "space-between"
  },
  headerTitleBox: {
    flexDirection: "row",
    alignItems: 'center'
  },
  headerTitle: {
    color: "#B2002D",
    fontSize: 16,
    fontFamily: "Montserrat",
    marginLeft: 20
  },
  removeAllBookings: {
    color: "#B2002D",
  },
  bookButton: {
    backgroundColor: "#B2002D",
    paddingHorizontal: 36,
    paddingVertical: 6,
    borderRadius: 40,
    flexDirection: "row",
    alignItems: 'center',
  },
  bookButtonText: {
    color: "#ffffff",
    fontWeight: "bold"
  },
  arrowRight: {
    marginLeft: 10
  },
  contentBox: {
    marginBottom: 20
  },
  contentInformationBox: {
    marginHorizontal: 10,
    marginTop: 20,
  },
  contentText: {
    fontSize: 16,
    marginBottom: 10
  },
  buttonBox: {
    alignItems: 'center',
    marginTop: 30
  }
})