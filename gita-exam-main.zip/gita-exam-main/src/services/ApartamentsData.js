const Apartaments = [
  {
    id: 1,
    image: require("../assets/images/001_villa.jpg"),
    name: "Villa Jane will astonish every guest with its breathtaking views",
    price: "$2000",
    address: "Aspen",
    bedRoom: "05",
    totalArea: "7,600 sq ft (710 m²)"
  },
  {
    id: 2,
    image: require("../assets/images/002_villa.jpg"),
    name: "Ultra-exclusive mountain home Ranch-inspired luxury living",
    price: "$3500",
    address: "Blanca",
    bedRoom: "04",
    totalArea: "6,500 sq ft (610 m²)"
  },
  {
    id: 3,
    image: require("../assets/images/003_villa.jpg"),
    name: "High specification new cottage with traditional character nestled",
    price: "$2300",
    address: "Campo",
    bedRoom: "03",
    totalArea: "5,400 sq ft (510 m²)"
  },
  {
    id: 4,
    image: require("../assets/images/004_villa.jpg"),
    name: "Wonderful character cottage in the popular village of Croscombe",
    price: "$3900",
    address: "Dillon",
    bedRoom: "02",
    totalArea: "4,300 sq ft (410 m²)"
  },
  {
    id: 5,
    image: require("../assets/images/005_villa.jpg"),
    name: "Large Detached house close to city centre with parking",
    price: "$1800",
    address: "Eaton",
    bedRoom: "01",
    totalArea: "3,200 sq ft (310 m²)"
  },
  {
    id: 6,
    image: require("../assets/images/006_villa.jpg"),
    name: "Chalet-style home that combines privacy with in-town",
    price: "$3100",
    address: "Fleming",
    bedRoom: "06",
    totalArea: "9,700 sq ft (810 m²)"
  },
  {
    id: 7,
    image: require("../assets/images/007_villa.jpg"),
    name: "Detached character cottage minutes away from Millfield, Street",
    price: "$4000",
    address: "Grover",
    bedRoom: "07",
    totalArea: "8,800 sq ft (910 m²)"
  },
  {
    id: 8,
    image: require("../assets/images/008_villa.jpg"),
    name: "Period Cottage in need of renovation in half an acre of garden",
    price: "$2500",
    address: "Kremmling",
    bedRoom: "08",
    totalArea: "5,900 sq ft (470 m²)"
  },
  {
    id: 9,
    image: require("../assets/images/009_villa.jpg"),
    name: "Magnificent family house with views, outbuildings, anciliary accommodation",
    price: "$2800",
    address: "Longmont",
    bedRoom: "09",
    totalArea: "5,400 sq ft (280 m²)"
  },
  {
    id: 10,
    image: require("../assets/images/010_villa.jpg"),
    name: "Attractive period cottage in popular village near Castle Cary Station.",
    price: "$3300",
    address: "Mead",
    bedRoom: "10",
    totalArea: "1,120 sq ft (410 m²)"
  },
];

export default Apartaments;