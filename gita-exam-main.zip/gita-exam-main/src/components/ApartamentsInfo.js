import React from "react";
import { Text, StyleSheet, View, TouchableOpacity, Image } from "react-native";
import { useNavigation } from '@react-navigation/native';

// Imported Icon
import Location from "react-native-vector-icons/Ionicons";

export default function ApartamentsInfo({ id, image, name, price, address, bedRoom, totalArea }) {
  const navigation = useNavigation();
  return (
    <>
      <Image source={image} style={styles.image} />
      <Text style={styles.name}>{name}</Text>
      <Text style={styles.price}>{price}</Text>
      <View style={styles.locationAndMoreContainer}>
        <View>
          <Text style={styles.address}>
            <Location name="location-sharp" size={22} />
            {address}
          </Text>
        </View>
        <View style={styles.moreAndBookContainer}>
          <TouchableOpacity activeOpacity={0.6} style={styles.moreButton}>
            <Text style={styles.moreTitle}>More</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('BookVilla', { id: id, image: image, price: price, bedRoom: bedRoom, totalArea: totalArea, name: name })} activeOpacity={0.6} style={styles.bookButton}>
            <Text style={styles.bookTitle}>Book Villa</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  image: {
    width: "100%",
    height: 224,
    borderWidth: 1,
    borderColor: "black",
    resizeMode: "contain"
  },
  name: {
    color: "black",
    fontSize: 16,
    fontFamily: "Montserrat",
  },
  price: {
    color: "#B2002D",
    fontSize: 16,
    fontFamily: "Montserrat",
  },
  address: {
    color: "black",
    fontSize: 17,
  },
  locationAndMoreContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 10,
  },
  moreAndBookContainer: {
    flexDirection: "row",
  },
  moreButton: {
    backgroundColor: "#B2002D",
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderRadius: 30,
    marginRight: 6,
  },
  moreTitle: {
    color: "white",
    fontSize: 15,
    fontFamily: "Montserrat",
    textTransform: "uppercase",
  },
  bookButton: {
    backgroundColor: "#B2002D",
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderRadius: 30,
  },
  bookTitle: {
    color: "white",
    fontSize: 15,
    fontFamily: "Montserrat",
  },
});
