import React from 'react'
import { StyleSheet, Text, View, FlatList, Image } from 'react-native'

// Imported Icon
import Location from "react-native-vector-icons/Ionicons";

const SearchFilter = ({ data, input }) => {
    return (
        <FlatList
            contentContainerStyle={styles.contentContainerStyle}
            data={data} renderItem={({ item }) => {
                if (input === "") {
                    return (
                        <View style={styles.container}>
                            <Image source={item.image} style={styles.image} />
                            <Text style={styles.name}>{item.name}</Text>
                            <View style={styles.addressndPriceBox}>
                                <View style={styles.addressBox}>
                                    <Location name="location-sharp" size={22} />
                                    <Text style={styles.address}> {item.address}</Text>
                                </View>
                                <Text style={styles.price}>{item.price}</Text>
                            </View>
                        </View>
                    )
                }
                if (item.name.toLowerCase().includes(input.toLowerCase())) {
                    return (
                        <View style={styles.container}>
                            <Image source={item.image} style={styles.image} />
                            <Text style={styles.name}>{item.name}</Text>
                            <View style={styles.addressndPriceBox}>
                                <View style={styles.addressBox}>
                                    <Location name="location-sharp" size={22} />
                                    <Text style={styles.address}> {item.address}</Text>
                                </View>
                                <Text style={styles.price}>{item.price}</Text>
                            </View>
                        </View>
                    )
                }
                if (item.address.toLowerCase().includes(input.toLowerCase())) {
                    return (
                        <View style={styles.container}>
                            <Image source={item.image} style={styles.image} />
                            <Text style={styles.name}>{item.name}</Text>
                            <View style={styles.addressndPriceBox}>
                                <View style={styles.addressBox}>
                                    <Location name="location-sharp" size={22} />
                                    <Text style={styles.address}> {item.address}</Text>
                                </View>
                                <Text style={styles.price}>{item.price}</Text>
                            </View>
                        </View>
                    )
                } if (item.price.toLowerCase().includes(input.toLowerCase())) {
                    return (
                        <View style={styles.container}>
                            <Image source={item.image} style={styles.image} />
                            <Text style={styles.name}>{item.name}</Text>
                            <View style={styles.addressndPriceBox}>
                                <View style={styles.addressBox}>
                                    <Location name="location-sharp" size={22} />
                                    <Text style={styles.address}> {item.address}</Text>
                                </View>
                                <Text style={styles.price}>{item.price}</Text>
                            </View>
                        </View>
                    )
                }
            }}
        />
    )
}

export default SearchFilter

const styles = StyleSheet.create({
    image: {
        width: "100%",
        height: 224,
        borderWidth: 1,
        borderColor: "black",
        resizeMode: "contain"
    },
    contentContainerStyle: {
        paddingBottom: 110,
    },
    container: {
        marginBottom: 6
    },
    name: {
        color: "black",
        fontSize: 16,
        fontFamily: "Montserrat",
    },
    price: {
        color: "#B2002D",
        fontSize: 16,
        fontFamily: "Montserrat",
        marginLeft: 15,
        fontWeight: "bold"
    },
    addressndPriceBox: {
        flexDirection: "row",
        alignItems: 'center',
        marginTop: 10,
    },
    addressBox: {
        flexDirection: "row",
        alignItems: 'center',
    },
    address: {
        color: "black",
        fontSize: 17,
    },
})