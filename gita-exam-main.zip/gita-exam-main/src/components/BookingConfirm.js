import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

// Imported Icons
import Close from "react-native-vector-icons/AntDesign"
import ArrowRight from "react-native-vector-icons/Ionicons"
import Check from "react-native-vector-icons/Feather"

export default function BookingConfirm({ navigation: { navigate } }) {
    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigate('Home')}>
                    <Close name="close" size={33} color="#B2002D" />
                </TouchableOpacity>
            </View>
            <View style={styles.content}>
                <View style={styles.checkmarkBox}>
                    <Check name="check" size={50} color="#B2002D" style={styles.checkmark} />
                </View>
                <View style={styles.contentTextBox}>
                    <Text style={styles.bookingConfirm}>Booking Confirm</Text>
                    <Text style={styles.weWillCall}>We will call you for more
                        information in 24 Hours.</Text>
                    <Text style={styles.thanksForBooking}>Thanks for Booking !!</Text>
                </View>
                <View style={styles.buttonsBox}>
                    <TouchableOpacity activeOpacity={0.7} onPress={() => navigate('Bookings')} style={styles.bookButton}>
                        <Text style={styles.bookButtonText}>View More</Text>
                        <ArrowRight name='ios-arrow-forward-circle-sharp' size={30} color="#ffffff"
                            style={styles.arrowRight} />
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        marginTop: 50,
        marginHorizontal: 5,
    },
    header: {
        marginHorizontal: 10,
        flexDirection: "row",
        justifyContent: "flex-end"
    },
    content: {
        marginTop: 90
    },
    contentTextBox: {
        alignItems: 'center'
    },
    bookingConfirm: {
        fontSize: 32,
        marginTop: 30,
        marginBottom: 20,
        fontFamily: "Montserrat",
        color: "#515c6e"
    },
    weWillCall: {
        color: "gray",
        marginBottom: 20,
        fontSize: 17,
        marginHorizontal: 50,
        textAlign: 'center',
        fontFamily: "Montserrat",
        color: "#515c6e"
    },
    thanksForBooking: {
        color: "gray",
        marginBottom: 30,
        fontSize: 17,
        fontFamily: "Montserrat",
        color: "#515c6e"
    },
    bookButton: {
        backgroundColor: "#B2002D",
        paddingHorizontal: 40,
        paddingVertical: 10,
        borderRadius: 40,
        flexDirection: "row",
        alignItems: 'center',
    },
    bookButtonText: {
        color: "#ffffff",
        fontWeight: "bold"
    },
    arrowRight: {
        marginLeft: 10
    },
    buttonsBox: {
        alignItems: 'center'
    },
    checkmarkBox: {
        alignItems: 'center'
    },
    checkmark: {
        backgroundColor: "#ffffff",
        height: 110,
        width: 110,
        textAlign: 'center',
        textAlignVertical: 'center',
        borderRadius: 60,
    }
})