import React, { useState } from 'react'
import { View, Text, StyleSheet, TouchableOpacity, LogBox, Modal, Alert, Image } from 'react-native'
import AsyncStorage from '@react-native-async-storage/async-storage'

// Imported Icons
import ArrowLeft from "react-native-vector-icons/Octicons"
import Dot from "react-native-vector-icons/Entypo"
import ArrowUp from "react-native-vector-icons/Ionicons"
import ArrowRight from "react-native-vector-icons/Ionicons"

// reason of using LogBox > https://reactnavigation.org/docs/troubleshooting/
LogBox.ignoreLogs([
    'Non-serializable values were found in the navigation state',
]);

export default function BookVilla({ route, navigation }) {
    // Hooks for modals
    const [modalVisible, setModalVisible] = useState(false);

    // Storing data with AsyncStorage and using concat to add a new item with an exist items
    const storeData = async () => {
        try {
            const bookings = await AsyncStorage.getItem('booking');
            if (bookings === null) {
                AsyncStorage.setItem('booking', JSON.stringify([route.params]))
            }
            if (JSON.parse(bookings).filter(b => b.id === route.params.id)?.length === 0) {
                console.log(JSON.parse(bookings).concat(route.params))
                AsyncStorage.setItem('booking', JSON.stringify(JSON.parse(bookings).concat(route.params)))
            }
        } catch (error) {
            console.log(error)
        }
    }

    return (
        <>
            <View style={styles.container}>
                <View style={styles.header}>
                    <View style={styles.detailsBox}>
                        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                            <ArrowLeft name="chevron-left" size={33} color="#B2002D" />
                        </TouchableOpacity>
                        <Text style={styles.details}>Details</Text>
                    </View>
                    <View>
                        <Text style={styles.price}>Price {route.params.price}</Text>
                    </View>
                </View>
                <View>
                    <Image source={route.params.image} style={styles.image} />
                </View>
                <View style={styles.dotBox}>
                    <Dot name='dot-single' size={30} color="#D3D3D3" />
                    <Dot name='dot-single' size={30} color="#808080" />
                    <Dot name='dot-single' size={30} color="#D3D3D3" />
                </View>
                <View style={styles.categoriesBox}>
                    <Text style={styles.categiesTitles}>Amiantus</Text>
                    <Text style={styles.categoriesDetails}>Details</Text>
                    <Text style={styles.categiesTitles}>Reviews</Text>
                </View>
                <View style={styles.categoriesBadroomBox}>
                    <Text style={styles.categoriesinfos}>Bedroom</Text>
                    <Text style={styles.categoriesinfosResult}>{route.params.bedRoom}</Text>
                </View>
                <View style={styles.categoriesTotalAreaBox}>
                    <Text style={styles.categoriesinfos}>Total area</Text>
                    <Text style={styles.categoriesinfosResult}>{route.params.totalArea}</Text>
                </View>
                <View style={styles.categoriesNameBox}>
                    <Text style={styles.categoriesNameResult}>{route.params.name}</Text>
                </View>
                <View style={styles.buttonsBox}>
                    <TouchableOpacity activeOpacity={0.7} style={styles.shareButton}>
                        <Text style={styles.shareButtonText}>Share this</Text>
                        <ArrowUp name='arrow-up-circle' size={30} color="#808080"
                            style={styles.arrowUp} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => setModalVisible(true)} activeOpacity={0.7} style={styles.bookButton}>
                        <Text style={styles.bookButtonText}>Book</Text>
                        <ArrowRight name='ios-arrow-forward-circle-sharp' size={30} color="#ffffff"
                            style={styles.arrowRight} />
                    </TouchableOpacity>
                </View>
            </View>
            <View style={styles.centeredView}>
                <Modal
                    animationType="none"
                    transparent={true}
                    visible={modalVisible}
                    onRequestClose={() => {
                        Alert.alert("Modal has been closed.");
                        setModalVisible(!modalVisible);
                    }}>
                    <View style={styles.centeredView}>
                        <View style={styles.modalView}>
                            <Text style={styles.modalText}>Are you sure you want to Book Villa?</Text>
                            <View style={styles.modalButtonBox}>
                                <TouchableOpacity onPress={() => setModalVisible(!modalVisible)}>
                                    <Text style={styles.modalCancelText}>Cancel</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={styles.modalYes}
                                    // onPressIn immediately when a touch is engaged
                                    onPressIn={storeData}
                                    // and invoked before onPress.
                                    onPress={() => navigation.navigate('BookingConfirm')} >
                                    <Text style={styles.modalYesText}>Yes</Text>
                                </TouchableOpacity></View>
                        </View>
                    </View>
                </Modal>
            </View>
        </>
    )
}

const styles = StyleSheet.create({
    image: {
        width: "100%",
        height: 224,
        borderWidth: 1,
        borderColor: "black",
        resizeMode: "contain"
    },
    container: {
        contentContainerStyle: {
            flexGrow: 1,
        },
        marginTop: 50,
        marginHorizontal: 5,
    },
    header: {
        marginHorizontal: 10,
        alignItems: 'center',
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 10
    },
    detailsBox: {
        flexDirection: "row",
        alignItems: 'center'
    },
    details: {
        color: "#B2002D",
        fontSize: 16,
        fontFamily: "Montserrat",
        marginLeft: 20
    }, price: {
        color: "#B2002D",
        fontSize: 16,
        fontFamily: "Montserrat",
    },
    dotBox: {
        flexDirection: 'row',
        justifyContent: "space-between",
        marginHorizontal: 110,
        marginTop: 20
    },
    categoriesBox: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 16,
    },
    categiesTitles: {
        color: '#808080',
        fontSize: 16
    },
    categoriesDetails: {
        color: "#B2002D",
        fontSize: 16,
        fontFamily: "Montserrat",
    },
    categoriesBadroomBox: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 30,
        marginTop: 10
    },
    categoriesinfos: {
        color: '#B0B0B0',
        textTransform: "uppercase"
    },
    categoriesTotalAreaBox: {
        marginTop: 50,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 30,
    },
    categoriesinfosResult: {
        color: '#808080',
    },
    categoriesNameBox: {
        lignItems: 'center',
        marginTop: 90
    },
    categoriesNameResult: {
        textAlign: 'center',
        fontSize: 20,
        marginHorizontal: 30,
    },
    buttonsBox: {
        flexDirection: 'row',
        justifyContent: "space-between",
        marginHorizontal: 20,
        marginTop: 50
    },
    shareButton: {
        backgroundColor: "#D3D3D3",
        paddingHorizontal: 20,
        paddingVertical: 6,
        borderRadius: 40,
        flexDirection: "row",
        alignItems: 'center',
    },
    shareButtonText: {
        color: "#808080",
        textTransform: "uppercase",
        fontWeight: "bold"
    },
    arrowUp: {
        marginLeft: 10
    },
    bookButton: {
        backgroundColor: "#B2002D",
        paddingHorizontal: 36,
        paddingVertical: 6,
        borderRadius: 40,
        flexDirection: "row",
        alignItems: 'center',
    },
    bookButtonText: {
        color: "#ffffff",
        fontWeight: "bold"
    },
    arrowRight: {
        marginLeft: 10
    },
    // Modal styles
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },
    modalView: {
        margin: 20,
        backgroundColor: "white",
        borderRadius: 6,
        borderColor: "black",
        borderWidth: 0.8,
        padding: 20,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 10,
    },
    button: {
        borderRadius: 20,
        padding: 10,
        elevation: 2
    },
    buttonOpen: {
        backgroundColor: "#F194FF",
    },
    buttonClose: {
        backgroundColor: "#2196F3",
    },
    textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center"
    },
    modalText: {
        marginBottom: 15,
        textAlign: "center",
        color: "gray"
    },
    modalButtonBox: {
        flexDirection: "row",
        marginLeft: 60,
        marginTop: 10,
    },
    modalCancelText: {
        color: "#B2002D",
        textTransform: 'uppercase'
    },
    modalYes: {
        marginLeft: 20
    },
    modalYesText: {
        color: "#B2002D",
        textTransform: 'uppercase'
    }
})